import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'DataController.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class chooseDestinationPage extends StatelessWidget {
  City city;


  chooseDestinationPage({required this.city});

  late GoogleMapController mapController;



  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }
  @override
  Widget build(BuildContext context) {

    _myDrawerOptions(name,route){
      return ListTile(
        title: Text(name),
        onTap: (){
          DataController.tourList.add(new Tour(startDate: "startDate", endDate: "endDate", location: city.name, isAbroad: city.isAbroad));
          Navigator.pushNamed(context, route);
        },
      );
    }

    return  Scaffold(
      appBar: AppBar(
        title:  Text('Plan Your Trip in ${city.name} ',style: TextStyle(color: Colors.white ,fontWeight: FontWeight.bold),),
        elevation: 2,
        backgroundColor: Colors.blue,),
      drawer: NavigationDrawer(
        children: [
          DrawerHeader(
            decoration: BoxDecoration(color: Colors.blue),
            child: Column(
              children: [Text('Drawer Header'),
              Icon(Icons.pin_drop, size: 100,)],
            ),),
          _myDrawerOptions("Save Trip","/main"),
        ],
      ),
      body: GoogleMap(
              onMapCreated: _onMapCreated,
              initialCameraPosition: CameraPosition(
                target: LatLng(city.Lng, city.Lat),
                zoom: 11.0,
              ),
            ),

    );
  }
}
_tile(Destination destination) {
  return ListTile(
    title: Text(destination.name,
        style: TextStyle(fontSize: 150,fontWeight: FontWeight.bold)),
    subtitle: Text("In ${destination.city}",),
    trailing: Text("",
      style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),),
  );
}
