
import 'package:finalprojectapp/chooseLocationPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'DataController.dart';

class myAppMain extends StatelessWidget {
  User user;

  myAppMain({required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(" Welcome ${user.username}",style: TextStyle(fontSize: 30,color: Colors.white,fontWeight: FontWeight.bold),),backgroundColor: Colors.blue,) ,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          spacing: 50,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.lightBlueAccent
              ),
              child: Row( mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 3)
                  ),
                  margin: EdgeInsets.all(5),
                  child: SizedBox(
                    height: 160,
                    width: 208,
                    child: Column(children: [
                      GestureDetector(
                        onTap:  (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>chooseLocationPage(currentTour: new Tour.isAbroad(isAbroad: 0))));
                        },
                        child: Icon(Icons.car_rental,size: 110,),
                      ),
                      Text("Local",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),)
                      ],
                    )
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 3)),
                  margin: EdgeInsets.all(5),
                  child: SizedBox(
                    height: 160,
                    width: 208,
                    child: Column(children: [
                      GestureDetector(
                        onTap:(){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>chooseLocationPage(currentTour: new Tour.isAbroad(isAbroad: 1))));
                        } ,
                        child: Icon(Icons.airplanemode_on,size: 110,),
                      ),
                      Text("Abroad",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),)
                    ],),
                  )
                ),
              ],
            ),)
            ,
            Container(
              decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(width: 3,color: Colors.black38))
              ),
              child: Text("Your Tours",style: TextStyle(fontSize: 50,fontWeight: FontWeight.bold),),
            ),
            Expanded(child:  ListView.builder(
                padding: EdgeInsets.all(12),
                itemCount: DataController.tourList.length,
                itemBuilder: (BuildContext context, int index) {
                  return _tile(DataController.tourList[index]);
                }

            ))
          ],
        ),
      ),
    );
  }
}

_tile(Tour tour) {
  return ListTile(
    title: Text("Tour in ${tour.location}",
        style: TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Text("From ${tour.startDate} to ${tour.endDate}",),
    trailing: Text(tour.destinations.length.toString(),
      style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),),
  );
}
