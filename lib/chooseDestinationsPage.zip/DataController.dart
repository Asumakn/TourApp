import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

void main(){


}





class DataController {
  static int test = 0;
  static late Database database;
 static List<User> userList = [];
  static List<City> cityList = [City(name: "Munich", isAbroad: 1,Lng: 48.137154,Lat: 11.576124), City(name: "London", isAbroad: 1, Lng: 51.5074, Lat: -0.1278) ];
  static List<Tour> tourList = [];
  static List<Destination> destinationList = [];

  static Future<void> initDatabase() async {
    database =
    await openDatabase(join(await getDatabasesPath(), 'finalproject.db'),
        onCreate: (db, version) {
      Batch batch = db.batch();
      batch.execute( "CREATE TABLE users (username TEXT, password TEXT)",);
      batch.execute( "CREATE TABLE tours (startDate TEXT, endDate TEXT, location TEXT,  isAbroad TEXT)");
      batch.execute( "CREATE TABLE cities (name TEXT, isAbroad TEXT )");
      batch.execute( "CREATE TABLE destinations (name TEXT, city TEXT )" );
        } , version: 2);
    refreshUser();
    refreshDestination();
    refreshCity();
    refreshTour();
    // this is mandatory to
    // refresh the database every time there is a change in the data
  }
  static Future<void> insertUser(User user) async {

    await database.insert(
        'users',
        {'username': user.username, 'password': user.password},
        conflictAlgorithm: ConflictAlgorithm.replace
    );
  }
  static Future<void> insertTour(Tour tour) async {

    await database.insert(
        'tours',
        {'startDate': tour.startDate, 'endDate': tour.endDate, 'location':tour.location, 'isAbroad':tour.isAbroad},
        conflictAlgorithm: ConflictAlgorithm.replace
    );
  }
  static Future<void> insertCity(City city) async {

    await database.insert(
        'cities',
        {'name': city.name, 'isAbroad': city.isAbroad},
        conflictAlgorithm: ConflictAlgorithm.replace
    );

    refreshCity();
  }
  static  Future<void> insertDestination(Destination destination) async {
    await database.insert(
        'destinations',
        {'name': destination.name, 'city': destination.city},
        conflictAlgorithm: ConflictAlgorithm.replace
    );
  }
  static Future<void> refreshUser() async {

    final List<Map<String, Object?>> userMap = await database.query('users');

    test = userMap.length;
    userList = userMap.map((userMap) {
      return User(
          username: userMap['username'] as String,
          password: userMap['password'] as String
      );
    }).toList();


  }
  static Future<void> refreshTour() async{
    final List<Map<String, Object?>> tourMaps = await database.query('tours');

    tourList = tourMaps.map((tourMaps){
      return Tour(
          startDate: tourMaps['startDate'] as String,
          endDate: tourMaps['endDate'] as String,
          location: tourMaps['location'] as String,
          isAbroad: tourMaps['isAbroad'] as int
      );
    }).toList();
  }
  static Future<void> refreshCity() async{
    final List<Map<String, Object?>> cityMaps = await database.query('cities');
   /* cityList = cityMaps.map((cityMaps){
      return City(
          name: cityMaps['name'] as String,
          isAbroad: cityMaps['isAbroad'] as String
      );
   }).toList();*/
  }
  static  Future<void> refreshDestination() async{
    final List<Map<String, Object?>> destinationMaps = await database.query('destinations');
    destinationList = destinationMaps.map((destinationMaps){
      return Destination(
          name: destinationMaps['name'] as String,
          city: destinationMaps['city'] as String
      );
    }).toList();

  }
}



class User {
  var username;
  var password;

  User({required this.username, required this.password});

  @override
  String toString() {
    return 'User{username: $username, password: $password}';
  }
  Map<String, Object?> toMap() {
    return {'username': username, 'password': password};
  }

}
class Tour{
  var startDate;
  var endDate;
  var location;
  int isAbroad;
  List destinations = [];

  Tour({required this.startDate, required this.endDate, required this.location, required this.isAbroad});
  Tour.isAbroad({required this.isAbroad});
}

class City{
  var name;
  int isAbroad;
  double Lat;
  double Lng;
  List destinationList = [];
  City({required this.name, required this.isAbroad, required this.Lng, required this.Lat});
  Map<String, Object?> toMap() {
    return {'name': name, 'isAbroad': isAbroad};
  }
}

class Destination{
  var name;
  var city;

  Destination({required this.name, required this.city});

}