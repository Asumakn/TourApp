import 'dart:async';

import 'package:finalprojectapp/chooseDestinationsPage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'DataController.dart';
import 'mainPage.dart';
import 'registerPage.dart';
import 'chooseLocationPage.dart';

void main(){


  runApp(MyApp());

}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: "/main",
      routes: {
        "/": (context)=>myAppLogin(),
        "/main":(context)=>myAppMain(user:new User(username: "username", password: "password")),
        "/register": (context)=> myAppRegister(),
        "/location": (context)=> chooseLocationPage(currentTour: new Tour.isAbroad(isAbroad: 2)),
        "/destination": (context)=> chooseDestinationPage(city: DataController.cityList[1])
      },

    );
  }
}

class myAppHome extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return myAppLogin();
  }
}

class myAppLogin extends StatefulWidget {

  @override
  State<myAppLogin> createState() => _myAppLoginState();
}


class _myAppLoginState extends State<myAppLogin> {

  TextEditingController usernameController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
 @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {

DataController.initDatabase();
DataController.refreshUser();


    return  Scaffold(
      appBar: AppBar(title: Text("Login Page",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),backgroundColor: Colors.blue,),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.all(60),
              child:TextField(
                decoration:InputDecoration(
                  hintText: 'Enter Username',
                ) ,
                controller: usernameController,
                style: TextStyle(fontSize: 25),
              ),
            ),
            Container(
              margin: EdgeInsets.all(60),
              child:TextField(
                decoration:InputDecoration(
                  hintText: 'Enter Password',
                ) ,
                controller: passwordController,
                style: TextStyle(fontSize: 25),
                obscureText: true,
              ),
            ),
SizedBox(
  height: 110,
),
            SizedBox(
              width: 400,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder()),
                  onPressed: (){
            for(var item in DataController.userList){
            if(usernameController.text == item.username){
            if(passwordController.text == item.password){
            _clear();
            Navigator.push(context, MaterialPageRoute(builder: (context)=>myAppMain( user: item,)));
            }
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Password is Incorrect")));
            }
            }
            setState(() {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Username is Invalid")));
            });
            }, child: Text("Enter")),
            ),
            SizedBox(
              height: 50,
            ),
            SizedBox(
              width: 400,
              child:  ElevatedButton(onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=> myAppRegister()));
              }, child: Text("Register"),
                style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder()),

              ),
            )

          ],
        ),
      ),
    );
  }
  _clear(){
    usernameController.clear();
    passwordController.clear();
  }
  }
   _tile(Tour tour) {
     return ListTile(
       title: Text("Tour in ${tour.location}",
           style: TextStyle(fontWeight: FontWeight.bold)),
       subtitle: Text("From ${tour.startDate} to ${tour.endDate}",),
       trailing: Text(tour.destinations.length.toString(),
         style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),),
     );
   }

