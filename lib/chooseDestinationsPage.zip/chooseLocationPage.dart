import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'DataController.dart';
import 'chooseDestinationsPage.dart';

class chooseLocationPage extends StatelessWidget {
  Tour currentTour;

  chooseLocationPage({required this.currentTour});

  @override
  Widget build(BuildContext context) {

    _tile(City city1) {
      return ListTile(
        shape:  RoundedRectangleBorder(
          side: BorderSide(color: Colors.black, width: 1),
          borderRadius: BorderRadius.circular(5),
        ),
        onTap: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>chooseDestinationPage(city: city1)));},
        title: Text(city1.name,
            style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold)),
        subtitle: Text(city1.isAbroad.toString(),),
        trailing: Icon(Icons.travel_explore,size: 55,),
      );
    }
    return Scaffold(
      appBar: AppBar(title: Text("Choose a City to Explore ",style: TextStyle(color:Colors.white,fontWeight: FontWeight.bold),),backgroundColor: Colors.blue,),
      body: Center(
        child: Column(
          children: [
            Expanded(
                child:  ListView.builder(
                padding: EdgeInsets.all(12),
                itemCount: DataController.cityList.length,
                itemBuilder: (BuildContext context, int index) {
                  if(currentTour.isAbroad == DataController.cityList[index].isAbroad ) {
                    return _tile(DataController.cityList[index]);
                  }
                  return null;
                }

            ))
          ],
        ),
      ),
    );
  }


}
